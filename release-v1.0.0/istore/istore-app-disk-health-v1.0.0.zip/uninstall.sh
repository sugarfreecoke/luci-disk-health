#!/bin/sh
# iStore-app uninstall hook for luci-app-disk-health
printf '\n==> [disk-health] 开始卸载...\n'

FILES='
/etc/config/disk_health
/usr/lib/lua/luci/controller/disk_health.lua
/usr/lib/lua/luci/model/disk_health.lua
/usr/lib/lua/luci/model/cbi/disk_health.lua
/usr/lib/lua/luci/po/en/disk_health.po
/usr/lib/lua/luci/po/zh_Hans/disk_health.po
/usr/lib/lua/luci/view/disk_health/overview.htm
/usr/share/rpcd/acl.d/luci-app-disk-health.json
'
DIRS='
/usr/lib/lua/luci/view/disk_health
/usr/lib/lua/luci/model/cbi
'
removed=0
for f in $FILES; do
    if [ -f "$f" ]; then
        rm -f "$f"
        removed=$((removed + 1))
    fi
done
for d in $DIRS; do
    [ -d "$d" ] && [ -z "$(ls -A "$d" 2>/dev/null)" ] && rmdir "$d" 2>/dev/null
done

rm -rf /tmp/luci-* 2>/dev/null || true
/etc/init.d/rpcd restart  2>/dev/null || true
/etc/init.d/uhttpd restart 2>/dev/null || true

if [ -f /usr/lib/lua/luci/controller/disk_health.lua ]; then
    printf '[!!!] 控制器文件仍在，卸载可能未完成\n' >&2
    exit 1
fi
printf '[OK] 已删除 %d 个文件，卸载完成。请刷新 LuCI 页面。\n' "$removed"
exit 0
