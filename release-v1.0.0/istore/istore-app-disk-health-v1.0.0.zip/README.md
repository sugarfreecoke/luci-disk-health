# 磁盘健康监控 (luci-app-disk-health)

一个在 LuCI 中实时展示 **NVMe / SATA / eMMC / SD / USB / VirtIO 硬盘**健康度与
**剩余寿命** 的轻量插件，特别适合 iStoreOS / OpenWrt 软路由、NAS、ARM 硬路由场景。

## 功能特性

| 设备类型     | 来源                | 能力                                                 |
| ------------ | ------------------- | ---------------------------------------------------- |
| NVMe         | `smartctl`          | 健康度 / 温度 / 寿命% / 累计写入 / 可用保留空间       |
| SATA / HDD   | `smartctl`          | 健康度 / 温度 / 重映射扇区 / 寿命%                    |
| USB          | `smartctl`          | 健康度 / 温度 / 寿命% (部分 UASP 桥接)               |
| eMMC         | sysfs + mmc extcsd  | 寿命% (life_time) / EOL 状态 / pre_eol_info          |
| SD           | sysfs + mmc extcsd  | 寿命% / EOL 状态                                     |
| VirtIO       | `smartctl`          | 健康度 / 温度                                         |
| **NAND 闪存** | UBI / MTD sysfs    | **擦除计数估算寿命** / 坏块率 / ECC 失败 / UBI 只读   |

## 特色亮点

- **真正支持硬路由 NAND**：MT7981 / IPQ6000 等 ubionly 方案的路由器
  自动读取 UBI 的 `max_ec` / `mean_ec` / `bad_peb_count`，按用户配置的
  `nand_rated_cycles` 估算剩余寿命。
- **依赖自检**：插件会自动检测 `smartctl` / `mmc` 命令是否存在，
  缺失时给出可一键粘贴的 `opkg install` 命令。
- **零架构依赖**：纯 Lua + 配置文件，`LUCI_PKGARCH=all`，不挑平台。
- **可调阈值**：温度/寿命/坏块告警阈值、所有可调参数都在设置页一键改。

## 安装方法

### 方法 1：iStore 商店（推荐）
在 iStore 商店搜索 `disk-health` → 点击安装。

### 方法 2：手动上传
下载 `istore-app-disk-health-v1.0.0.tar.gz` 后，到 iStoreOS 后台，
进入 iStore 商店 → 本地安装 → 上传 tarball。

### 方法 3：SSH
```sh
scp istore-app-disk-health-v1.0.0.tar.gz root@192.168.1.1:/tmp/
ssh root@192.168.1.1
tar -xzf /tmp/istore-app-disk-health-v1.0.0.tar.gz -C /tmp/
sh /tmp/disk-health/install.sh
```

## 卸载

iStore 商店点卸载按钮，或：
```sh
sh /tmp/disk-health/uninstall.sh
```

## 许可

Apache-2.0
