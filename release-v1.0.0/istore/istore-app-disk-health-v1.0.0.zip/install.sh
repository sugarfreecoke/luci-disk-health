#!/bin/sh
# iStore-app install hook for luci-app-disk-health
# 由 iStore 后端调用，与之前 dh_setup.sh 等价
printf '\n==> [disk-health] 开始安装...\n'

# 提取 data.tar.gz（与应用 tarball 在同一目录的 packages/ 子目录）
HERE="$(cd "$(dirname "$0")"; pwd)"
PAYLOAD="$HERE"/packages/data.tar.gz
if [ ! -f "$PAYLOAD" ]; then
    printf '[!!!] 找不到 %s，请重新下载本应用\n' "$PAYLOAD" >&2
    exit 1
fi

# 1) 直接把 data.tar.gz 解到 /（iStore 沙箱内已是 root）
printf '==> 释放文件到 / ...\n'
tar -xzf "$PAYLOAD" -C /
if [ $? -ne 0 ]; then
    printf '[!!!] tar 释放失败\n' >&2
    exit 1
fi

# 2) 清理 luci 缓存 + reload 服务
printf '==> 清理缓存并重启服务 ...\n'
rm -rf /tmp/luci-* 2>/dev/null || true
/etc/init.d/rpcd restart  2>/dev/null || true
/etc/init.d/uhttpd restart 2>/dev/null || true

# 3) 验证
if [ -f /usr/lib/lua/luci/controller/disk_health.lua ]; then
    printf '\n[OK] 安装完成。打开 LuCI -> 服务 -> 磁盘健康 查看。\n'
    exit 0
else
    printf '\n[!!!] 控制器文件未落地，请检查 overlay 写权限\n' >&2
    exit 1
fi
